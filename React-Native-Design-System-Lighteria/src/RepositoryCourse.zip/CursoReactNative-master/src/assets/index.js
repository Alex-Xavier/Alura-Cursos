// Images
import iconBag from './images/icone-sacola.png';
import iconCube from './images/icone-cubo.png';
import iconMenu from './images/icone-menu.png';

export { iconBag, iconCube, iconMenu };
