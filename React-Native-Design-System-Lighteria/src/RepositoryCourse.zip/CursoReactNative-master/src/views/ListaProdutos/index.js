import React, {Fragment} from 'react';
import {SafeAreaView, View} from 'react-native';
import Cabecalho from './componentes/Cabecalho';
import Lista from './componentes/Lista';

const ListaProdutos = () => {
  return <Lista />;
};

export default ListaProdutos;
