import * as Cores from './colors';
import * as Tipografia from './typography';

export {Tipografia, Cores};
